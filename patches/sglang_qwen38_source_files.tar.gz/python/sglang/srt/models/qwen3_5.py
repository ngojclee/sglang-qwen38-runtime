

# Copyright 2025 Qwen Team
# Copyright 2025 SGLang Team
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Inference-only Qwen3.5 model and Qwen3.5 MoE model compatible with HuggingFace weights."""

import logging
from functools import lru_cache
from typing import Iterable, Optional, Set, Tuple, Union

import torch

from compressed_tensors import unpack_from_int32

def unpack_4bit_gdn(packed_w: torch.Tensor, scale: torch.Tensor, group_size: int = 128) -> torch.Tensor:
    N, K_packed = packed_w.shape
    orig_shape = torch.Size([N, K_packed * 8])
    unpacked = unpack_from_int32(packed_w, num_bits=4, shape=orig_shape, packed_dim=1)
    scale_expanded = scale.repeat_interleave(group_size, dim=1)
    return unpacked.to(scale.dtype) * scale_expanded

import torch.nn as nn
import triton

from sglang.jit_kernel.triton.gdn_fused_proj import (
    fused_qkvzba_split_reshape_cat_contiguous,
)

# Layers - Attention
from sglang.kernels.ops.attention.fla.layernorm_gated import RMSNorm as RMSNormGated
from sglang.kernels.ops.layernorm.elementwise import fused_sigmoid_mul

# Configs
from sglang.srt.configs.qwen3_5 import (
    Qwen3_5Config,
    Qwen3_5MoeConfig,
    Qwen3_5TextConfig,
)

# Distributed
from sglang.srt.distributed import get_pp_group
from sglang.srt.eplb.expert_distribution import get_global_expert_distribution_recorder
from sglang.srt.eplb.expert_location import ModelConfigForExpertLocation
from sglang.srt.layers.attention.mamba.mamba import mamba_v2_sharded_weight_loader
from sglang.srt.layers.communicator import LayerCommunicator, LayerScatterModes
from sglang.srt.layers.dp_attention import (
    is_dp_attention_enabled,
)

# Layers - Others
from sglang.srt.layers.layernorm import GemmaRMSNorm

# Layers - Linear
from sglang.srt.layers.linear import (
    ColumnParallelLinear,
    MergedColumnParallelLinear,
    QKVParallelLinear,
    RowParallelLinear,
)
from sglang.srt.layers.moe.fused_moe_triton.layer import FusedMoE
from sglang.srt.layers.parameter import (
    BlockQuantScaleParameter,
    PerTensorScaleParameter,
)
from sglang.srt.layers.quantization.base_config import QuantizationConfig
from sglang.srt.layers.radix_attention import RadixAttention
from sglang.srt.layers.radix_linear_attention import RadixLinearAttention
from sglang.srt.layers.rotary_embedding import get_rope
from sglang.srt.layers.utils import PPMissingLayer, get_layer_id
from sglang.srt.layers.vocab_parallel_embedding import VocabParallelEmbedding, ParallelLMHead
from sglang.srt.layers.logits_processor import LogitsProcessor
from sglang.srt.layers.pooler import Pooler, PoolingType
from sglang.srt.model_executor.cuda_graph_config import (
    Backend,
    Phase,
    check_cuda_graph_backend,
)
from sglang.srt.model_executor.forward_batch_info import ForwardBatch, PPProxyTensors
from sglang.srt.model_executor.runner import get_is_capture_mode
from sglang.srt.model_loader.weight_utils import (
    default_weight_loader,
    sharded_weight_loader,
)
from sglang.srt.models.qwen2_moe import (
    Qwen2MoeMLP,
    Qwen2MoeSparseMoeBlock,
    can_fuse_shared_expert,
)

# Models
from sglang.srt.models.qwen3_vl import Qwen3VLForConditionalGeneration
from sglang.srt.models.utils import (
    fused_qk_gemma_rmsnorm,
    fused_qk_gemma_rmsnorm_with_gate,
)
from sglang.srt.runtime_context import (
    get_forward,
    get_parallel,
    get_server_args,
    get_stream,
)

# Utils
from sglang.srt.utils import (
    LazyValue,
    add_prefix,
    cpu_has_amx_support,
    get_bool_env_var,
    is_cpu,
    is_cuda,
    is_gfx95_supported,
    is_hip,
    is_npu,
    is_xpu,
    make_layers,
    set_weight_attrs,
    use_intel_amx_backend,
)
from sglang.srt.utils.hf_transformers_utils import get_processor, get_rope_config

logger = logging.getLogger(__name__)
_is_cuda = is_cuda()
_is_npu = is_npu()
_is_cpu = is_cpu()
_is_gfx95 = is_gfx95_supported()
_is_hip = is_hip()
_is_xpu = is_xpu()
_use_aiter = get_bool_env_var("SGLANG_USE_AITER") and _is_hip
_hip_use_alt_stream = get_bool_env_var("SGLANG_ALT_STREAM") and _is_hip
_gdn_use_alt_stream = _is_cuda or (
    get_bool_env_var("SGLANG_GDN_QKVZ_BA_ALT_STREAM", "False") and _hip_use_alt_stream
)
_qknorm_use_alt_stream = _is_cuda or (
    get_bool_env_var("SGLANG_QK_NORM_ALT_STREAM", "False") and _hip_use_alt_stream
)
_is_amx_available = cpu_has_amx_support()

cached_get_processor = lru_cache(get_processor)


def _disable_shared_experts_fusion() -> bool:
    # Resolved lazily: the global server args is not set at module import time
    # (e.g. when this module is imported by unit tests).
    return get_server_args().disable_shared_experts_fusion


if _is_cuda:
    from sglang.kernels.ops.attention.fused_qk_rmsnorm_rope_gate import (
        fused_qk_gemma_rmsnorm_rope_gate,
    )

if _is_cpu:
    fused_sigmoid_mul = torch.ops.sgl_kernel.fused_sigmoid_mul_cpu
    fused_qk_gemma_rmsnorm = torch.ops.sgl_kernel.fused_qk_gemma_rmsnorm_cpu
    fused_qk_gemma_rmsnorm_with_gate = (
        torch.ops.sgl_kernel.fused_qk_gemma_rmsnorm_with_gate_cpu
    )
    fused_qkvzba_split_reshape_cat_contiguous = (
        torch.ops.sgl_kernel.fused_qkvzba_split_reshape_cat_contiguous_cpu
    )

if _is_npu:
    from sgl_kernel_npu.norm.split_qkv_rmsnorm_rope import (
        split_qkvgate_gemma_rmsnorm_rope,
    )


class Qwen3_5GatedDeltaNet(nn.Module):
    def __init__(
        self,
        config: Qwen3_5TextConfig,
        layer_id: int,
        quant_config: Optional[QuantizationConfig] = None,
        alt_stream: Optional[torch.cuda.Stream] = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.config = config
        self.attn_tp_rank = get_parallel().attn_tp_rank
        self.attn_tp_size = get_parallel().attn_tp_size
        self.hidden_size = config.hidden_size
        self.num_v_heads = (
            config.linear_num_value_heads
            if not _is_cpu
            else config.linear_num_value_heads_cpu
        )
        self.num_k_heads = (
            config.linear_num_key_heads
            if not _is_cpu
            else config.linear_num_key_heads_cpu
        )
        self.head_k_dim = config.linear_key_head_dim
        self.head_v_dim = config.linear_value_head_dim
        self.key_dim = self.head_k_dim * self.num_k_heads
        self.value_dim = self.head_v_dim * self.num_v_heads
        self.alt_stream = alt_stream

        self.conv_kernel_size = config.linear_conv_kernel_dim
        self.layer_id = layer_id
        self.activation = config.hidden_act
        self.output_gate_type = config.output_gate_type
        self.layer_norm_epsilon = config.rms_norm_eps

        # Conv1d layer
        self.conv_dim = self.key_dim * 2 + self.value_dim
        self.conv1d = ColumnParallelLinear(
            input_size=self.conv_kernel_size,
            output_size=self.conv_dim,
            bias=False,
            quant_config=None,
            tp_rank=self.attn_tp_rank,
            tp_size=self.attn_tp_size,
            prefix=add_prefix("conv1d", prefix),
        )
        self.conv1d.weight.data = self.conv1d.weight.data.unsqueeze(1)

        # projection of the input hidden states
        self.in_proj_qkvz = self.create_qkvz_proj(
            hidden_size=self.hidden_size,
            key_dim=self.key_dim,
            value_dim=self.value_dim,
            quant_config=None,
            prefix=add_prefix("in_proj_qkvz", prefix),
            tp_rank=self.attn_tp_rank,
            tp_size=self.attn_tp_size,
        )

        self.in_proj_ba = self.create_ba_proj(
            hidden_size=self.hidden_size,
            num_v_heads=self.num_v_heads,
            quant_config=None,
            prefix=add_prefix("in_proj_ba", prefix),
            tp_rank=self.attn_tp_rank,
            tp_size=self.attn_tp_size,
        )

        # Override weight loaders for packed checkpoint format.
        # Important: for FP8, this must cover not only `.weight` but also
        # `weight_scale_inv` / `weight_scale` / `input_scale` if present.
        self._bind_packed_weight_loaders(self.in_proj_qkvz)
        self._bind_packed_weight_loaders(self.in_proj_ba)
        self._fused_input_proj_cpu_enabled = LazyValue(
            lambda: (
                _is_cpu
                and self.in_proj_qkvz.weight.dtype == torch.bfloat16
                and self.in_proj_ba.weight.dtype == torch.bfloat16
                and self.in_proj_qkvz.bias is None
                and self.in_proj_ba.bias is None
                and use_intel_amx_backend(self.in_proj_qkvz)
                and use_intel_amx_backend(self.in_proj_ba)
            )
        )

        # Conv1d weight loader setup
        query_key_settings = (self.key_dim, 0, False)
        value_settings = (self.value_dim, 0, False)

        self._override_weight_loader(
            self.conv1d.weight,
            mamba_v2_sharded_weight_loader(
                [
                    query_key_settings,
                    query_key_settings,
                    value_settings,
                ],
                self.attn_tp_size,
                self.attn_tp_rank,
            ),
        )

        # State parameters
        self.dt_bias = nn.Parameter(
            torch.ones(self.num_v_heads // self.attn_tp_size),
        )
        self.A_log = nn.Parameter(
            torch.empty(self.num_v_heads // self.attn_tp_size, dtype=torch.float32),
        )

        set_weight_attrs(self.A_log, {"weight_loader": sharded_weight_loader(0)})
        set_weight_attrs(self.dt_bias, {"weight_loader": sharded_weight_loader(0)})

        conv_weights = self.conv1d.weight.view(
            self.conv1d.weight.size(0), self.conv1d.weight.size(2)
        )
        self.attn = RadixLinearAttention(
            layer_id=layer_id,
            num_q_heads=self.num_k_heads // self.attn_tp_size,
            num_k_heads=self.num_k_heads // self.attn_tp_size,
            num_v_heads=self.num_v_heads // self.attn_tp_size,
            head_q_dim=self.head_k_dim,
            head_k_dim=self.head_k_dim,
            head_v_dim=self.head_v_dim,
            conv_weights=conv_weights,
            bias=self.conv1d.bias,
            activation=self.activation,
            A_log=self.A_log,
            dt_bias=self.dt_bias,
        )

        self.norm = RMSNormGated(
            self.head_v_dim,
            eps=self.layer_norm_epsilon,
            group_size=None,
            norm_before_gate=True,
            device=torch.get_device_module().current_device(),
            dtype=torch.get_default_dtype(),
            **(
                {"activation": self.output_gate_type}
                if self.output_gate_type is not None
                else {}
            ),
        )

        self.out_proj = RowParallelLinear(
            self.value_dim,
            self.hidden_size,
            bias=False,
            input_is_parallel=True,
            reduce_results=False,
            quant_config=None,
            tp_rank=self.attn_tp_rank,
            tp_size=self.attn_tp_size,
            prefix=add_prefix("out_proj", prefix),
        )

    @staticmethod
    def _override_weight_loader(param, loader):
        """Robustly override loader for:
        1) BasevLLMParameter subclasses: real storage is `_weight_loader`
        2) regular Parameters that already have mutable `weight_loader`
        3) regular Parameters without `weight_loader` yet
        """
        if hasattr(param, "_weight_loader"):
            # FP8 / quantized BasevLLMParameter path
            param._weight_loader = loader
            return

        if hasattr(param, "weight_loader"):
            # Regular parameter/tensor that already has a mutable attr.
            # Do NOT call set_weight_attrs here, because it asserts when
            # overwriting an existing attribute.
            param.weight_loader = loader
            return

        # Fresh attribute on a normal tensor/Parameter
        set_weight_attrs(param, {"weight_loader": loader})

    def _bind_packed_weight_loaders(self, module):
        """Bind packed-checkpoint-aware loaders to all relevant params of a merged module."""
        for attr_name in ("weight", "weight_scale_inv", "weight_scale", "input_scale"):
            param = getattr(module, attr_name, None)
            if param is None:
                continue
            original_loader = getattr(param, "weight_loader", None)
            if original_loader is None:
                continue
            wrapped_loader = self._make_packed_weight_loader(module, original_loader)
            self._override_weight_loader(param, wrapped_loader)

    @staticmethod
    def _get_split_sizes_for_param(module, param, loaded_shard_id):
        """Return checkpoint-side split sizes for this param type."""
        if isinstance(param, BlockQuantScaleParameter):
            # Split by output blocks, not raw output sizes.
            block_n, _ = module.quant_method.quant_config.weight_block_size
            block_n = 1 if getattr(param, "format_ue8m0", False) else block_n
            return [
                (module.output_sizes[idx] + block_n - 1) // block_n
                for idx in loaded_shard_id
            ]

        if isinstance(param, PerTensorScaleParameter):
            # One logical scale per logical shard.
            return [1 for _ in loaded_shard_id]

        # Normal weight / non-block quant tensor
        return [module.output_sizes[idx] for idx in loaded_shard_id]

    @classmethod
    def _make_packed_weight_loader(cls, module, original_weight_loader):
        """Wrap the param's original loader so split checkpoints:
          - in_proj_qkv + in_proj_z -> merged in_proj_qkvz
          - in_proj_b + in_proj_a   -> merged in_proj_ba
        can load correctly for both normal and FP8 params.
        """

        def weight_loader(param, loaded_weight, loaded_shard_id=None):
            # Only intercept split-checkpoint tuple shards.
            # int shard_id and None should preserve original behavior.
            if isinstance(loaded_shard_id, tuple):
                split_sizes = cls._get_split_sizes_for_param(
                    module, param, loaded_shard_id
                )

                if loaded_weight.numel() == 1:
                    # Single-element tensor (scalar or [1]):
                    # broadcast to each logical shard.
                    chunks = [loaded_weight.view(-1)] * len(loaded_shard_id)
                else:
                    split_dim = getattr(param, "output_dim", 0)
                    if _is_cpu:
                        cpu_split_sizes = []
                        split_size_sum = sum(split_sizes)
                        target_size_sim = loaded_weight.size(split_dim)
                        for i in range(len(split_sizes)):
                            cpu_split_sizes.append(
                                int(target_size_sim * split_sizes[i] / split_size_sum)
                            )
                        assert (
                            sum(cpu_split_sizes) == target_size_sim
                        ), f"Padding the loaded weight failed due to sizes are not divisible cleanly from {cpu_split_sizes} to {target_size_sim}"
                        chunks = loaded_weight.split(cpu_split_sizes, dim=split_dim)
                    else:
                        chunks = loaded_weight.split(split_sizes, dim=split_dim)

                assert len(chunks) == len(loaded_shard_id), (
                    f"Chunk/shard mismatch: {len(chunks)=}, "
                    f"{len(loaded_shard_id)=}, {split_sizes=}"
                )

                for idx, chunk in zip(loaded_shard_id, chunks):
                    # Delegate each chunk to the param's original int-shard loader.
                    original_weight_loader(param, chunk, idx)
                return

            return original_weight_loader(param, loaded_weight, loaded_shard_id)

        return weight_loader

    def create_qkvz_proj(
        self,
        hidden_size: int,
        key_dim: int,
        value_dim: int,
        quant_config: QuantizationConfig | None,
        prefix: str,
        tp_rank: Optional[int] = None,
        tp_size: Optional[int] = None,
    ) -> MergedColumnParallelLinear:
        return MergedColumnParallelLinear(
            input_size=hidden_size,
            output_sizes=[key_dim, key_dim, value_dim, value_dim],
            bias=False,
            quant_config=quant_config,
            prefix=prefix,
            tp_rank=tp_rank,
            tp_size=tp_size,
        )

    def create_ba_proj(
        self,
        hidden_size: int,
        num_v_heads: int,
        quant_config: QuantizationConfig | None,
        prefix: str,
        tp_rank: Optional[int] = None,
        tp_size: Optional[int] = None,
    ) -> MergedColumnParallelLinear:
        # Qwen3.5 has separate in_proj_b and in_proj_a weights in the
        # checkpoint, which are loaded into the fused in_proj_ba parameter
        # via stacked_params_mapping with shard_id 0 and 1 respectively.
        return MergedColumnParallelLinear(
            input_size=hidden_size,
            output_sizes=[num_v_heads, num_v_heads],
            bias=False,
            quant_config=quant_config,
            prefix=prefix,
            tp_rank=tp_rank,
            tp_size=tp_size,
        )

    def fix_query_key_value_ordering(
        self,
        mixed_qkvz: torch.Tensor,
        mixed_ba: torch.Tensor,
    ):
        """
        Derives `query`, `key` and `value` tensors from `mixed_qkvzba`.
        """
        k_tp = self.key_dim // self.attn_tp_size
        v_tp = self.value_dim // self.attn_tp_size
        nv_tp = self.num_v_heads // self.attn_tp_size

        # Directly split, no head group reshape
        query, key, value, z = mixed_qkvz.split([k_tp, k_tp, v_tp, v_tp], dim=-1)
        b, a = mixed_ba.split([nv_tp, nv_tp], dim=-1)

        # value / z reshape to (seq, num_v_heads/tp, head_v_dim)
        value = value.reshape(value.size(0), -1, self.head_v_dim)
        z = z.reshape(z.size(0), -1, self.head_v_dim)

        return query, key, value, z, b, a

    def _forward_input_proj(self, hidden_states: torch.Tensor):
        if (
            _is_cpu
            or _is_npu
            or check_cuda_graph_backend(Phase.PREFILL, Backend.TC_PIECEWISE)
        ):
            DUAL_STREAM_TOKEN_THRESHOLD = 0
        else:
            DUAL_STREAM_TOKEN_THRESHOLD = 1024

        seq_len, _ = hidden_states.shape
        if (
            self.alt_stream is not None
            and get_is_capture_mode()
            and seq_len < DUAL_STREAM_TOKEN_THRESHOLD
            and _gdn_use_alt_stream
        ):
            current_stream = torch.cuda.current_stream()
            self.alt_stream.wait_stream(current_stream)
            projected_states_qkvz, _ = self.in_proj_qkvz(hidden_states)
            with torch.cuda.stream(self.alt_stream):
                projected_states_ba, _ = self.in_proj_ba(hidden_states)
            current_stream.wait_stream(self.alt_stream)
        elif self._fused_input_proj_cpu_enabled.value:
            projected_states_qkvz, projected_states_ba = (
                torch.ops.sgl_kernel.fused_input_proj_cpu(
                    hidden_states,
                    self.in_proj_qkvz.weight,
                    self.in_proj_ba.weight,
                    True,
                )
            )
        else:
            projected_states_qkvz, _ = self.in_proj_qkvz(hidden_states)
            projected_states_ba, _ = self.in_proj_ba(hidden_states)
        return projected_states_qkvz, projected_states_ba

    def forward(
        self,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
    ):
        """
        Forward pass with three parts:
        1. Input projection
        2. Core attention (custom op)
        3. Output projection
        """
        projected_states_qkvz, projected_states_ba = self._forward_input_proj(
            hidden_states
        )

        if self.num_v_heads // self.num_k_heads in [1, 2, 4] and not _is_npu:
            if _is_cpu:
                num_k_heads_tp = self.num_k_heads // self.attn_tp_size
                num_v_heads_tp = self.num_v_heads // self.attn_tp_size
            else:
                num_k_heads_tp = triton.cdiv(self.num_k_heads, self.attn_tp_size)
                num_v_heads_tp = triton.cdiv(self.num_v_heads, self.attn_tp_size)
            mixed_qkv, z, b, a = fused_qkvzba_split_reshape_cat_contiguous(
                projected_states_qkvz,
                projected_states_ba,
                num_k_heads_tp,
                num_v_heads_tp,
                self.head_k_dim,
                self.head_v_dim,
            )
        else:
            query, key, value, z, b, a = self.fix_query_key_value_ordering(
                projected_states_qkvz, projected_states_ba
            )
            b = b.contiguous()
            a = a.contiguous()

            query, key, value = map(
                lambda x: x.reshape(x.shape[0], -1), (query, key, value)
            )
            mixed_qkv = torch.cat((query, key, value), dim=-1)

        core_attn_out = self.attn(
            forward_batch,
            mixed_qkv=mixed_qkv,
            a=a,
            b=b,
        )

        z_shape_og = z.shape
        # reshape input data into 2D tensor
        core_attn_out = core_attn_out.reshape(-1, core_attn_out.shape[-1])
        z = z.reshape(-1, z.shape[-1])

        # Add padding for DP-Attn
        if core_attn_out.shape != z.shape:
            core_attn_out_pad = torch.zeros_like(z)
            core_attn_out_pad[: core_attn_out.shape[0], :] = core_attn_out
            core_attn_out = core_attn_out_pad

        core_attn_out = self.norm(core_attn_out, z)
        core_attn_out = core_attn_out.reshape(z_shape_og)
        core_attn_out = core_attn_out.reshape(*core_attn_out.shape[:-2], -1)

        output, _ = self.out_proj(core_attn_out)
        return output


class Qwen3_5LinearDecoderLayer(nn.Module):
    """Qwen3.5 Decoder Layer with Linear Attention (GatedDeltaNet)."""

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        layer_id: int,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        alt_stream: Optional[torch.cuda.Stream] = None,
        is_nextn: bool = False,
    ) -> None:
        super().__init__()
        self.config = config
        self.layer_id = layer_id

        linear_attn_quant_config = (
            None
            if quant_config and quant_config.get_name() == "modelopt_fp4"
            else quant_config
        )
        self.linear_attn = Qwen3_5GatedDeltaNet(
            config, layer_id, linear_attn_quant_config, alt_stream, prefix
        )

        # NOTE: Determine the MLP type based on the model type
        # Qwen3.5 use all layers for MLP / Qwen3.5-MoE use sparse MoE blocks
        if config.model_type == "qwen3_5_moe_text":
            self.mlp = Qwen2MoeSparseMoeBlock(
                layer_id=layer_id,
                config=config,
                quant_config=quant_config,
                alt_stream=(
                    alt_stream
                    if (_is_cuda or _disable_shared_experts_fusion())
                    else None
                ),
                prefix=add_prefix("mlp", prefix.replace(".linear_attn", "")),
                is_nextn=is_nextn,
                support_shared_expert_fusion=not _disable_shared_experts_fusion(),
            )
            is_layer_sparse = True
            is_previous_layer_sparse = True
            is_next_layer_sparse = True
        elif config.model_type == "qwen3_5_text":
            self.mlp = Qwen2MoeMLP(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                hidden_act=config.hidden_act,
                quant_config=quant_config,
                prefix=add_prefix("mlp", prefix.replace(".linear_attn", "")),
            )
            is_layer_sparse = False
            is_previous_layer_sparse = False
            is_next_layer_sparse = False
        else:
            raise ValueError(f"Invalid model type: {config.model_type}")

        self.layer_scatter_modes = LayerScatterModes.init_new(
            layer_id=layer_id,
            num_layers=config.num_hidden_layers,
            is_layer_sparse=is_layer_sparse,
            is_previous_layer_sparse=is_previous_layer_sparse,
            is_next_layer_sparse=is_next_layer_sparse,
        )

        self.input_layernorm = GemmaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = GemmaRMSNorm(
            config.hidden_size, eps=config.rms_norm_eps
        )
        self.layer_communicator = LayerCommunicator(
            layer_scatter_modes=self.layer_scatter_modes,
            input_layernorm=self.input_layernorm,
            post_attention_layernorm=self.post_attention_layernorm,
            allow_reduce_scatter=True,
            is_last_layer=(layer_id == config.num_hidden_layers - 1),
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        residual: Optional[torch.Tensor],
        **kwargs,
    ):
        forward_batch = kwargs.get("forward_batch", None)

        hidden_states, residual = (
            self.layer_communicator.prepare_attn_and_capture_last_layer_outputs(
                hidden_states,
                residual,
                forward_batch,
                captured_last_layer_outputs=kwargs.get(
                    "captured_last_layer_outputs", None
                ),
            )
        )

        if not forward_batch.forward_mode.is_idle():
            hidden_states = self.linear_attn(
                hidden_states,
                forward_batch,
            )

        # Fully Connected
        hidden_states, residual = self.layer_communicator.prepare_mlp(
            hidden_states, residual, forward_batch
        )

        mlp_reduce_scatter = self.layer_communicator.should_use_reduce_scatter(
            forward_batch
        )

        fuse_mlp_allreduce = (
            self.layer_communicator.should_fuse_mlp_allreduce_with_next_layer(
                forward_batch
            )
        )
        with get_forward().scoped(
            fuse_mlp_allreduce=fuse_mlp_allreduce,
            mlp_reduce_scatter=mlp_reduce_scatter,
        ):
            if isinstance(self.mlp, Qwen2MoeSparseMoeBlock):
                hidden_states = self.mlp(
                    hidden_states,
                    forward_batch,
                )
            else:
                hidden_states = self.mlp(hidden_states)
        if fuse_mlp_allreduce:
            hidden_states._sglang_needs_allreduce_fusion = True
        else:
            hidden_states, residual = self.layer_communicator.postprocess_layer(
                hidden_states, residual, forward_batch
            )

        return hidden_states, residual


class Qwen3_5AttentionDecoderLayer(nn.Module):
    """Qwen3.5 Decoder Layer with Full Attention."""

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        layer_id: int,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        alt_stream: Optional[torch.cuda.Stream] = None,
        is_nextn: bool = False,
    ) -> None:
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.attn_tp_rank = get_parallel().attn_tp_rank
        self.attn_tp_size = get_parallel().attn_tp_size
        self.total_num_heads = config.num_attention_heads
        assert self.total_num_heads % self.attn_tp_size == 0
        self.num_heads = self.total_num_heads // self.attn_tp_size
        self.total_num_kv_heads = config.num_key_value_heads
        if self.total_num_kv_heads >= self.attn_tp_size:
            assert self.total_num_kv_heads % self.attn_tp_size == 0
        else:
            assert self.attn_tp_size % self.total_num_kv_heads == 0
        self.num_kv_heads = max(1, self.total_num_kv_heads // self.attn_tp_size)
        self.head_dim = config.head_dim or (self.hidden_size // self.num_heads)
        self.q_size = self.num_heads * self.head_dim
        self.kv_size = self.num_kv_heads * self.head_dim
        self.scaling = self.head_dim**-0.5
        self.max_position_embeddings = getattr(config, "max_position_embeddings", 8192)

        self.rope_theta, rope_scaling = get_rope_config(config)
        self.partial_rotary_factor = getattr(config, "partial_rotary_factor", 1.0)
        self.layer_id = layer_id

        # If rope_scaling doesn't specify a scaling type, treat as no scaling
        if rope_scaling and not ("rope_type" in rope_scaling or "type" in rope_scaling):
            rope_scaling = None

        self.attn_output_gate = getattr(config, "attn_output_gate", True)
        if self.attn_output_gate:
            logger.warning_once("using attn output gate!")

        self.rotary_emb = get_rope(
            head_size=self.head_dim,
            rotary_dim=self.head_dim,
            max_position=self.max_position_embeddings,
            rope_scaling=rope_scaling,
            base=self.rope_theta,
            partial_rotary_factor=self.partial_rotary_factor,
            is_neox_style=True,
            dtype=torch.get_default_dtype(),
        )

        attn_quant_config = (
            None
            if quant_config and quant_config.get_name() == "modelopt_fp4"
            else quant_config
        )

        self.qkv_proj = QKVParallelLinear(
            config.hidden_size,
            self.head_dim,
            self.total_num_heads * (1 + self.attn_output_gate),
            self.total_num_kv_heads,
            bias=False,
            quant_config=attn_quant_config,
            tp_rank=self.attn_tp_rank,
            tp_size=self.attn_tp_size,
            prefix=add_prefix("qkv_proj", prefix),
        )

        self.o_proj = RowParallelLinear(
            self.total_num_heads * self.head_dim,
            config.hidden_size,
            bias=False,
            quant_config=attn_quant_config,
            reduce_results=False,
            tp_rank=self.attn_tp_rank,
            tp_size=self.attn_tp_size,
            prefix=add_prefix("o_proj", prefix),
        )

        self.attn = RadixAttention(
            self.num_heads,
            self.head_dim,
            self.scaling,
            num_kv_heads=self.num_kv_heads,
            layer_id=layer_id,
            prefix=f"{prefix}.attn",
        )

        # Dense MLP for non-MoE variant
        if config.model_type == "qwen3_5_text":
            self.mlp = Qwen2MoeMLP(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                hidden_act=config.hidden_act,
                quant_config=quant_config,
                prefix=add_prefix("mlp", prefix.replace(".self_attn", "")),
            )
            is_layer_sparse = False
            is_previous_layer_sparse = False
            is_next_layer_sparse = False
        elif config.model_type == "qwen3_5_moe_text":
            self.mlp = Qwen2MoeSparseMoeBlock(
                layer_id=layer_id,
                config=config,
                quant_config=quant_config,
                alt_stream=(
                    alt_stream
                    if (_is_cuda or _disable_shared_experts_fusion())
                    else None
                ),
                prefix=add_prefix("mlp", prefix.replace(".self_attn", "")),
                is_nextn=is_nextn,
                support_shared_expert_fusion=not _disable_shared_experts_fusion(),
            )
            is_layer_sparse = True
            is_previous_layer_sparse = True
            is_next_layer_sparse = True
        else:
            raise ValueError(f"Invalid model type: {config.model_type}")

        self.layer_scatter_modes = LayerScatterModes.init_new(
            layer_id=layer_id,
            num_layers=config.num_hidden_layers,
            is_layer_sparse=is_layer_sparse,
            is_previous_layer_sparse=is_previous_layer_sparse,
            is_next_layer_sparse=is_next_layer_sparse,
        )

        self.input_layernorm = GemmaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = GemmaRMSNorm(
            config.hidden_size, eps=config.rms_norm_eps
        )

        self.q_norm = GemmaRMSNorm(self.head_dim, eps=config.rms_norm_eps)
        self.k_norm = GemmaRMSNorm(self.head_dim, eps=config.rms_norm_eps)

        self.layer_communicator = LayerCommunicator(
            layer_scatter_modes=self.layer_scatter_modes,
            input_layernorm=self.input_layernorm,
            post_attention_layernorm=self.post_attention_layernorm,
            allow_reduce_scatter=True,
            is_last_layer=(layer_id == config.num_hidden_layers - 1),
        )

        self.alt_stream = alt_stream

    def _apply_qk_norm(
        self, q: torch.Tensor, k: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Apply Q/K normalization with optional alt_stream overlap."""
        if (
            self.alt_stream is not None
            and get_is_capture_mode()
            and _qknorm_use_alt_stream
        ):
            current_stream = torch.cuda.current_stream()
            self.alt_stream.wait_stream(current_stream)
            q_by_head = q.reshape(-1, self.head_dim)
            q_by_head = self.q_norm(q_by_head)
            with torch.cuda.stream(self.alt_stream):
                k_by_head = k.reshape(-1, self.head_dim)
                k_by_head = self.k_norm(k_by_head)
            current_stream.wait_stream(self.alt_stream)
        elif _is_hip or _is_xpu or _is_cpu:
            q_by_head, k_by_head = fused_qk_gemma_rmsnorm(
                q,
                k,
                self.q_norm.weight.data,
                self.k_norm.weight.data,
                self.q_norm.variance_epsilon,
                self.head_dim,
            )
        else:
            q_by_head = q.reshape(-1, self.head_dim)
            q_by_head = self.q_norm(q_by_head)
            k_by_head = k.reshape(-1, self.head_dim)
            k_by_head = self.k_norm(k_by_head)
        q = q_by_head.view(q.shape)
        k = k_by_head.view(k.shape)
        return q, k

    def forward_prepare_cuda_fused(self, positions, hidden_states):
        """Fused QK GemmaRMSNorm + NeoX RoPE + gate deinterleave."""
        qkv, _ = self.qkv_proj(hidden_states)
        if self.attn_output_gate:
            q_gate, k, v = qkv.split(
                [self.q_size * 2, self.kv_size, self.kv_size], dim=-1
            )
        else:
            q_gate, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        q_out, k_out, gate_out = fused_qk_gemma_rmsnorm_rope_gate(
            q_gate,
            k,
            self.q_norm.weight.data,
            self.k_norm.weight.data,
            self.rotary_emb.cos_sin_cache,
            positions,
            self.q_norm.variance_epsilon,
            self.num_heads,
            self.num_kv_heads,
            self.head_dim,
            self.rotary_emb.rotary_dim,
            has_gate=self.attn_output_gate,
        )
        seq_len = hidden_states.shape[0]
        q = q_out.view(seq_len, -1)
        k = k_out.view(seq_len, -1)
        gate = gate_out.view(seq_len, -1) if gate_out is not None else None
        return q, k, v, gate

    def forward_prepare_native(self, positions, hidden_states):
        qkv, _ = self.qkv_proj(hidden_states)
        if self.attn_output_gate:
            q_gate, k, v = qkv.split(
                [self.q_size * 2, self.kv_size, self.kv_size], dim=-1
            )
            orig_shape = q_gate.shape[:-1]
            q_gate = q_gate.view(*orig_shape, self.num_heads, -1)
            q, gate = torch.chunk(q_gate, 2, dim=-1)
            q = q.reshape(*orig_shape, -1)
            # gate stays as 3D strided view; fused_sigmoid_mul handles it directly
        else:
            q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
            gate = None

        q, k = self._apply_qk_norm(q, k)
        q, k = self.rotary_emb(positions, q, k)
        return q, k, v, gate

    def forward_prepare_fused_gate(self, positions, hidden_states):
        qkv, _ = self.qkv_proj(hidden_states)
        if self.attn_output_gate:
            q_gate, k, v = qkv.split(
                [self.q_size * 2, self.kv_size, self.kv_size], dim=-1
            )
            seq_len = q_gate.shape[0]
            q_flat, k_flat, gate_flat = fused_qk_gemma_rmsnorm_with_gate(
                q_gate,
                k,
                self.q_norm.weight.data,
                self.k_norm.weight.data,
                self.q_norm.variance_epsilon,
                self.head_dim,
                self.num_heads,
            )
            q = q_flat.view(seq_len, -1)
            k = k_flat.view(seq_len, -1)
            gate = gate_flat.view(seq_len, -1)
        else:
            q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
            gate = None
            q, k = self._apply_qk_norm(q, k)

        q, k = self.rotary_emb(positions, q, k)
        return q, k, v, gate

    def forward_prepare_npu(self, positions, hidden_states, forward_batch):
        qkv, _ = self.qkv_proj(hidden_states)
        # Calculate first full attention layer ID based on config
        if self.attn.layer_id == (self.config.full_attention_interval - 1):
            self.rotary_emb.get_cos_sin_with_position(positions)

        q, k, v, gate = split_qkvgate_gemma_rmsnorm_rope(
            qkv,
            self.rotary_emb.position_sin,
            self.rotary_emb.position_cos,
            self.q_size,
            self.kv_size,
            self.head_dim,
            int(self.head_dim * self.partial_rotary_factor),
            eps=self.q_norm.variance_epsilon,
            q_weight=self.q_norm.weight,
            k_weight=self.k_norm.weight,
        )
        return q, k, v, gate

    def self_attention(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
    ) -> torch.Tensor:
        """Full attention forward pass."""
        if _is_cuda and self.attn_output_gate:
            q, k, v, gate = self.forward_prepare_cuda_fused(
                positions=positions,
                hidden_states=hidden_states,
            )
        elif (_is_hip or _is_xpu or _is_cpu) and self.attn_output_gate:
            q, k, v, gate = self.forward_prepare_fused_gate(
                positions=positions,
                hidden_states=hidden_states,
            )
        elif (
            not _is_npu
            or forward_batch.forward_mode.is_extend_or_draft_extend_or_mixed()
            or not self.attn_output_gate
        ):
            q, k, v, gate = self.forward_prepare_native(
                positions=positions,
                hidden_states=hidden_states,
            )
        else:
            q, k, v, gate = self.forward_prepare_npu(
                positions=positions,
                hidden_states=hidden_states,
                forward_batch=forward_batch,
            )

        attn_output = self.attn(q, k, v, forward_batch)

        if self.attn_output_gate:
            if not _is_npu:
                attn_output = fused_sigmoid_mul(attn_output, gate, inplace=True)
            else:
                gate_val = gate.reshape(gate.shape[0], -1) if gate.ndim == 3 else gate
                attn_output.mul_(torch.sigmoid(gate_val))

        output, _ = self.o_proj(attn_output)
        return output

    def forward(
        self,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        residual: Optional[torch.Tensor],
        forward_batch: ForwardBatch,
        captured_last_layer_outputs: Optional[list[torch.Tensor]] = None,
        **kwargs,
    ):
        hidden_states, residual = (
            self.layer_communicator.prepare_attn_and_capture_last_layer_outputs(
                hidden_states,
                residual,
                forward_batch,
                captured_last_layer_outputs=captured_last_layer_outputs,
            )
        )

        if not forward_batch.forward_mode.is_idle():
            hidden_states = self.self_attention(
                positions=positions,
                hidden_states=hidden_states,
                forward_batch=forward_batch,
            )

        # Fully Connected
        hidden_states, residual = self.layer_communicator.prepare_mlp(
            hidden_states, residual, forward_batch
        )
        mlp_reduce_scatter = self.layer_communicator.should_use_reduce_scatter(
            forward_batch
        )

        fuse_mlp_allreduce = (
            self.layer_communicator.should_fuse_mlp_allreduce_with_next_layer(
                forward_batch
            )
        )
        with get_forward().scoped(
            fuse_mlp_allreduce=fuse_mlp_allreduce,
            mlp_reduce_scatter=mlp_reduce_scatter,
        ):
            if isinstance(self.mlp, Qwen2MoeSparseMoeBlock):
                hidden_states = self.mlp(
                    hidden_states,
                    forward_batch,
                )
            else:
                hidden_states = self.mlp(hidden_states)
        if fuse_mlp_allreduce:
            hidden_states._sglang_needs_allreduce_fusion = True
        else:
            hidden_states, residual = self.layer_communicator.postprocess_layer(
                hidden_states, residual, forward_batch
            )

        return hidden_states, residual


ALL_DECODER_LAYER_TYPES = {
    "attention": Qwen3_5AttentionDecoderLayer,
    "full_attention": Qwen3_5AttentionDecoderLayer,
    "linear_attention": Qwen3_5LinearDecoderLayer,
}


class Qwen3_5Model(nn.Module):
    """Qwen3.5 Model with support for dense variant."""

    packed_modules_mapping = {
        "qkv_proj": ["q_proj", "k_proj", "v_proj"],
        "gate_up_proj": ["gate_proj", "up_proj"],
        "in_proj_qkvz": ["in_proj_qkv", "in_proj_z"],
        "in_proj_ba": ["in_proj_b", "in_proj_a"],
    }

    supported_lora_modules = [
        "qkv_proj",
        "o_proj",
        "out_proj",
        "in_proj_qkvz",
        "gate_up_proj",
        "down_proj",
        "lm_head",
    ]

    def get_hidden_dim(self, module_name: str, layer_idx: int):
        config = self.config
        head_dim = config.head_dim or (config.hidden_size // config.num_attention_heads)

        if module_name == "qkv_proj":
            attn_output_gate = getattr(config, "attn_output_gate", True)
            q_heads = config.num_attention_heads * (2 if attn_output_gate else 1)
            return (
                config.hidden_size,
                head_dim * (q_heads + config.num_key_value_heads * 2),
            )
        elif module_name == "o_proj":
            return config.num_attention_heads * head_dim, config.hidden_size
        elif module_name == "out_proj":
            value_dim = config.linear_value_head_dim * config.linear_num_value_heads
            return value_dim, config.hidden_size
        elif module_name == "in_proj_qkvz":
            key_dim = config.linear_key_head_dim * config.linear_num_key_heads
            value_dim = config.linear_value_head_dim * config.linear_num_value_heads
            return config.hidden_size, key_dim * 2 + value_dim * 2
        elif module_name == "gate_up_proj":
            # MoE: shared expert uses shared_expert_intermediate_size
            # Dense: regular MLP uses intermediate_size
            is_moe = "moe" in getattr(config, "model_type", "")
            if is_moe:
                inter = config.shared_expert_intermediate_size
            else:
                inter = config.intermediate_size
            return config.hidden_size, inter * 2
        elif module_name == "down_proj":
            is_moe = "moe" in getattr(config, "model_type", "")
            if is_moe:
                inter = config.shared_expert_intermediate_size
            else:
                inter = config.intermediate_size
            return inter, config.hidden_size
        elif module_name == "gate_up_proj_moe":
            return config.hidden_size, config.moe_intermediate_size * 2
        elif module_name == "down_proj_moe":
            return config.moe_intermediate_size, config.hidden_size
        elif module_name == "embed_tokens":
            return config.vocab_size, config.hidden_size
        elif module_name == "lm_head":
            return config.hidden_size, config.vocab_size
        else:
            raise NotImplementedError(
                f"get_hidden_dim not implemented for {module_name}"
            )

    def _maybe_autodisable_shared_experts_fusion(self, config, quant_config):
        # Auto-disable fusion when the checkpoint can't fuse (e.g. MXFP4 Qwen3.5)
        # so the model still gets the #25885 multi-streaming path. ROCm-only.
        if (
            config.model_type == "qwen3_5_moe_text"
            and not get_server_args().disable_shared_experts_fusion
            and not can_fuse_shared_expert(config, quant_config)
        ):
            from sglang.srt.arg_groups.overrides import declare_load_time_override

            declare_load_time_override(
                "Qwen3_5ForCausalLM._maybe_autodisable_shared_experts_fusion",
                {"disable_shared_experts_fusion": True},
            )
            logger.info(
                "Qwen3.5: shared-expert fusion not supported for this checkpoint; "
                "auto-disabling (multi-streaming #25885 still applies)."
            )

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        is_nextn: bool = False,
    ) -> None:
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.pp_group = get_pp_group()

        if _is_hip:
            self._maybe_autodisable_shared_experts_fusion(config, quant_config)

        alt_stream = get_stream("alt") if _is_cuda or _hip_use_alt_stream else None

        # Embedding layer
        if self.pp_group.is_first_rank:
            self.embed_tokens = VocabParallelEmbedding(
                config.vocab_size,
                config.hidden_size,
                org_num_embeddings=config.vocab_size,
                enable_tp=not is_dp_attention_enabled(),
            )
        else:
            self.embed_tokens = PPMissingLayer()

        # Decoder layers
        def get_layer(idx: int, prefix: str):
            layer_types_list = getattr(config, "layers_block_type", None) or getattr(config, "layer_types", None)
            if layer_types_list is not None:
                layer_type = layer_types_list[idx]
            else:
                layer_type = "full_attention" if (idx + 1) % config.full_attention_interval == 0 else "linear_attention"
            layer_class = ALL_DECODER_LAYER_TYPES[layer_type]
            if layer_type in ("attention", "full_attention"):
                prefix = add_prefix("self_attn", prefix)
            else:
                prefix = add_prefix("linear_attn", prefix)
            return layer_class(
                config=config,
                layer_id=idx,
                quant_config=quant_config,
                prefix=prefix,
                alt_stream=alt_stream,
                is_nextn=is_nextn,
            )

        self.layers, self._start_layer, self._end_layer = make_layers(
            config.num_hidden_layers,
            get_layer,
            pp_rank=self.pp_group.rank_in_group,
            pp_size=self.pp_group.world_size,
            prefix=f"{prefix}.layers",
        )

        # Final normalization
        if self.pp_group.is_last_rank:
            self.norm = GemmaRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        else:
            self.norm = PPMissingLayer()

        self.layers_to_capture = []

    def get_input_embeddings(self):
        return self.embed_tokens

    def set_dflash_layers_to_capture(self, layers_to_capture: list[int]):
        self.layers_to_capture = layers_to_capture
        for layer_id in self.layers_to_capture:
            setattr(self.layers[layer_id], "_is_layer_to_capture", True)

    @property
    def start_layer(self) -> int:
        return self._start_layer

    @property
    def end_layer(self) -> int:
        return self._end_layer

    @torch.no_grad()
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        forward_batch: ForwardBatch,
        input_embeds: Optional[torch.Tensor] = None,
        pp_proxy_tensors: Optional[PPProxyTensors] = None,
        input_deepstack_embeds: Optional[torch.Tensor] = None,
    ) -> Union[torch.Tensor, PPProxyTensors]:
        # Initialize hidden states
        if self.pp_group.is_first_rank:
            if input_embeds is None:
                hidden_states = self.embed_tokens(input_ids)
            else:
                hidden_states = input_embeds
            residual = None
        else:
            assert pp_proxy_tensors is not None
            hidden_states = pp_proxy_tensors["hidden_states"]
            residual = pp_proxy_tensors["residual"]

        aux_hidden_states = []
        # Pass through decoder layers
        for layer_idx in range(self.start_layer, self.end_layer):
            layer = self.layers[layer_idx]
            with get_global_expert_distribution_recorder().with_current_layer(
                layer_idx
            ):
                hidden_states, residual = layer(
                    positions=positions,
                    hidden_states=hidden_states,
                    residual=residual,
                    forward_batch=forward_batch,
                    captured_last_layer_outputs=(
                        aux_hidden_states
                        if getattr(layer, "_is_layer_to_capture", False)
                        else None
                    ),
                )

            # Process deepstack embeddings if provided
            if (
                input_deepstack_embeds is not None
                and input_deepstack_embeds.numel() > 0
                and layer_idx < 3
            ):
                sep = self.hidden_size * layer_idx
                hidden_states.add_(
                    input_deepstack_embeds[:, sep : sep + self.hidden_size]
                )

        # Return intermediate tensors for pipeline parallelism
        if not self.pp_group.is_last_rank:
            return PPProxyTensors(
                {
                    "hidden_states": hidden_states,
                    "residual": residual,
                }
            )

        # Apply final normalization
        if hidden_states.shape[0] != 0:
            if residual is None:
                hidden_states = self.norm(hidden_states)
            else:
                hidden_states, _ = self.norm(hidden_states, residual)

        if len(aux_hidden_states) == 0:
            return hidden_states

        return hidden_states, aux_hidden_states

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))
        gdn_buffer = {}
        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "visual" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")

            if name.endswith(".weight_shape") and ".linear_attn." in name:
                continue

            # GDN compressed-tensors unpacking adapter
            if ".linear_attn." in name:
                layer_id = get_layer_id(name)
                if "in_proj_qkv.weight_packed" in name:
                    gdn_buffer[(layer_id, "qkv_p")] = loaded_weight
                elif "in_proj_qkv.weight_scale" in name:
                    gdn_buffer[(layer_id, "qkv_s")] = loaded_weight
                elif "in_proj_z.weight_packed" in name:
                    gdn_buffer[(layer_id, "z_p")] = loaded_weight
                elif "in_proj_z.weight_scale" in name:
                    gdn_buffer[(layer_id, "z_s")] = loaded_weight
                elif "in_proj_b.weight_packed" in name:
                    gdn_buffer[(layer_id, "b_p")] = loaded_weight
                elif "in_proj_b.weight_scale" in name:
                    gdn_buffer[(layer_id, "b_s")] = loaded_weight
                elif "in_proj_a.weight_packed" in name:
                    gdn_buffer[(layer_id, "a_p")] = loaded_weight
                elif "in_proj_a.weight_scale" in name:
                    gdn_buffer[(layer_id, "a_s")] = loaded_weight
                elif "out_proj.weight_packed" in name:
                    gdn_buffer[(layer_id, "out_p")] = loaded_weight
                elif "out_proj.weight_scale" in name:
                    gdn_buffer[(layer_id, "out_s")] = loaded_weight

                if (layer_id, "qkv_p") in gdn_buffer and (layer_id, "qkv_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "qkv_p"))
                    s = gdn_buffer.pop((layer_id, "qkv_s"))
                    qkv_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_qkvz.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, qkv_fp, (0, 1, 2))
                        loaded_params.add(f"{target_name}.qkv")

                if (layer_id, "z_p") in gdn_buffer and (layer_id, "z_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "z_p"))
                    s = gdn_buffer.pop((layer_id, "z_s"))
                    z_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_qkvz.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, z_fp, 3)
                        loaded_params.add(f"{target_name}.z")

                if (layer_id, "b_p") in gdn_buffer and (layer_id, "b_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "b_p"))
                    s = gdn_buffer.pop((layer_id, "b_s"))
                    b_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_ba.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, b_fp, 0)
                        loaded_params.add(f"{target_name}.b")

                if (layer_id, "a_p") in gdn_buffer and (layer_id, "a_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "a_p"))
                    s = gdn_buffer.pop((layer_id, "a_s"))
                    a_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_ba.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, a_fp, 1)
                        loaded_params.add(f"{target_name}.a")

                if (layer_id, "out_p") in gdn_buffer and (layer_id, "out_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "out_p"))
                    s = gdn_buffer.pop((layer_id, "out_s"))
                    out_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.out_proj.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, out_fp)
                        loaded_params.add(target_name)

                if any(x in name for x in ["in_proj_qkv", "in_proj_z", "in_proj_b", "in_proj_a", "out_proj.weight_packed", "out_proj.weight_scale"]):
                    continue
            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if weight_name not in name:
                    continue

                if "mlp.experts" in name:
                    continue

                name = name.replace(weight_name, param_name)
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                # Skip layers on other devices.
                # if is_pp_missing_parameter(name, self):
                #     continue
                if name not in params_dict:
                    continue
                param = params_dict[name]
                weight_loader = getattr(param, "weight_loader")
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                if name not in params_dict:
                    logger.warning(f"Parameter {name} not found in params_dict")
                    continue
                param = params_dict[name]

                weight_loader = getattr(param, "weight_loader", default_weight_loader)
                weight_loader(param, loaded_weight)
            loaded_params.add(name)
        return loaded_params

    @classmethod
    def get_model_config_for_expert_location(cls, config):
        text_config = getattr(config, "text_config", config)
        return ModelConfigForExpertLocation(
            num_layers=getattr(text_config, "num_hidden_layers", 0),
            num_logical_experts=getattr(text_config, "num_experts", 0),
            num_groups=None,
        )


class Qwen3_5MoeModel(Qwen3_5Model):
    def __init__(
        self,
        config: Qwen3_5TextConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
    ) -> None:
        super().__init__(config=config, quant_config=quant_config, prefix=prefix)

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        # Params for weights, fp8 weight scales, fp8 activation scales
        # (param_name, weight_name, expert_id, shard_id)
        expert_params_mapping = FusedMoE.make_expert_params_mapping(
            ckpt_gate_proj_name="gate_proj",
            ckpt_down_proj_name="down_proj",
            ckpt_up_proj_name="up_proj",
            num_experts=self.config.num_experts,
        )

        # Skip loading extra parameters for GPTQ/modelopt models.
        ignore_suffixes = (
            ".bias",
            "_bias",
            ".k_scale",
            "_k_scale",
            ".v_scale",
            "_v_scale",
            ".weight_scale",
            "_weight_scale",
            ".input_scale",
            "_input_scale",
        )

        is_fused_expert = False
        fused_expert_params_mapping = [
            ("experts.w13_weight", "experts.gate_up_proj", 0, "w1"),
            ("experts.w2_weight", "experts.down_proj", 0, "w2"),
        ]

        num_experts = self.config.num_experts

        def load_fused_expert_weights(
            name: str,
            params_dict: dict,
            loaded_weight: torch.Tensor,
            shard_id: str,
            num_experts: int,
        ):
            if name not in params_dict:
                return False
            param = params_dict[name]
            weight_loader = param.weight_loader
            # let ep moe layer to gracefully handle expert_ids that do not belong to local moe rank
            for expert_id in range(num_experts):
                curr_expert_weight = loaded_weight[expert_id]
                weight_loader(
                    param,
                    curr_expert_weight,
                    name,
                    shard_id,
                    expert_id,
                )
            return True

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))

        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "visual" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")

            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if "experts.gate_up_proj" in name or "experts.down_proj" in name:
                    is_fused_expert = True
                    expert_params_mapping = fused_expert_params_mapping

                # Skip non-stacked layers and experts (experts handled below).
                if weight_name not in name:
                    continue

                # We have mlp.experts[0].gate_proj in the checkpoint.
                # Since we handle the experts below in expert_params_mapping,
                # we need to skip here BEFORE we update the name, otherwise
                # name will be updated to mlp.experts[0].gate_up_proj, which
                # will then be updated below in expert_params_mapping
                # for mlp.experts[0].gate_gate_up_proj, which breaks load.
                if "mlp.experts" in name:
                    continue
                name = name.replace(weight_name, param_name)
                # Skip loading extra parameters for GPTQ/modelopt models.
                if name.endswith(ignore_suffixes) and name not in params_dict:
                    continue

                if name not in params_dict:
                    continue

                param = params_dict[name]
                weight_loader = param.weight_loader
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                # Track if this is an expert weight to enable early skipping
                is_expert_weight = False

                for mapping in expert_params_mapping:
                    param_name, weight_name, expert_id, shard_id = mapping
                    if weight_name not in name:
                        continue
                    # Anyway, this is an expert weight and should not be
                    # attempted to load as other weights later
                    is_expert_weight = True
                    name_mapped = name.replace(weight_name, param_name)
                    if is_fused_expert:
                        if "experts.gate_up_proj" in name:
                            loaded_weight = loaded_weight.chunk(2, dim=-2)
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[0],
                                "w1",
                                num_experts,
                            )
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[1],
                                "w3",
                                num_experts,
                            )
                        else:
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight,
                                shard_id,
                                num_experts,
                            )
                    else:
                        # Skip loading extra parameters for GPTQ/modelopt models.
                        if (
                            name_mapped.endswith(ignore_suffixes)
                            and name_mapped not in params_dict
                        ):
                            continue
                        param = params_dict[name_mapped]
                        # We should ask the weight loader to return success or
                        # not here since otherwise we may skip experts with
                        # # other available replicas.
                        weight_loader = param.weight_loader
                        weight_loader(
                            param,
                            loaded_weight,
                            name_mapped,
                            shard_id=shard_id,
                            expert_id=expert_id,
                        )
                    name = name_mapped
                    break
                else:
                    if is_expert_weight:
                        # This is an expert weight but not mapped to this rank, skip all remaining processing
                        continue

                    # Skip loading extra parameters for GPTQ/modelopt models.
                    if name.endswith(ignore_suffixes) and name not in params_dict:
                        continue

                    if name in params_dict.keys():
                        param = params_dict[name]
                        weight_loader = getattr(
                            param, "weight_loader", default_weight_loader
                        )
                        weight_loader(param, loaded_weight)
                    else:
                        logger.warning(f"Parameter {name} not found in params_dict")
            loaded_params.add(name)

        return loaded_params




class Qwen3_5ForCausalLM(nn.Module):
    packed_modules_mapping = Qwen3_5Model.packed_modules_mapping
    supported_lora_modules = Qwen3_5Model.supported_lora_modules

    def __init__(
        self,
        config: Qwen3_5TextConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.pp_group = get_pp_group()
        self.config = config
        self.quant_config = quant_config
        self.model = Qwen3_5Model(
            config, quant_config=quant_config, prefix=add_prefix("model", prefix)
        )

        if self.pp_group.is_last_rank:
            if self.pp_group.world_size == 1 and getattr(config, "tie_word_embeddings", False):
                self.lm_head = self.model.embed_tokens
            else:
                self.lm_head = ParallelLMHead(
                    config.vocab_size,
                    config.hidden_size,
                    quant_config=quant_config,
                    prefix=add_prefix("lm_head", prefix),
                )
        else:
            self.lm_head = PPMissingLayer()

        self.logits_processor = LogitsProcessor(config)
        self.pooler = Pooler(pooling_type=PoolingType.LAST, normalize=True)
        self.capture_aux_hidden_states = False

    def get_input_embedding(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.model.get_input_embedding(input_ids)

    def get_input_embeddings(self) -> nn.Embedding:
        return self.model.embed_tokens

    def set_dflash_layers_to_capture(self, layers_to_capture: list[int]):
        self.model.set_dflash_layers_to_capture(layers_to_capture)

    @property
    def start_layer(self) -> int:
        return self.model.start_layer

    @property
    def end_layer(self) -> int:
        return self.model.end_layer

    @torch.no_grad()
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        forward_batch: ForwardBatch,
        input_embeds: Optional[torch.Tensor] = None,
        get_embedding: bool = False,
        pp_proxy_tensors: Optional[PPProxyTensors] = None,
    ) -> torch.Tensor:
        res = self.model(
            input_ids,
            positions,
            forward_batch,
            input_embeds=input_embeds,
            pp_proxy_tensors=pp_proxy_tensors,
        )
        if isinstance(res, tuple):
            hidden_states, aux_hidden_states = res
        else:
            hidden_states = res
            aux_hidden_states = None

        if self.pp_group.is_last_rank:
            if not get_embedding:
                return self.logits_processor(
                    input_ids,
                    hidden_states,
                    self.lm_head,
                    forward_batch,
                    aux_hidden_states,
                )
            else:
                return self.pooler(hidden_states, forward_batch)
        else:
            return hidden_states

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        stacked_params_mapping = [
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
        ]
        params_dict = dict(self.named_parameters(remove_duplicate=False))
        loaded_params: Set[str] = set()
        gdn_buffer = {}

        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name or "mtp" in name or "visual" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")
            if name.endswith(".weight_shape") and ".linear_attn." in name:
                continue

            if ".linear_attn." in name:
                layer_id = get_layer_id(name)
                if "in_proj_qkv.weight_packed" in name:
                    gdn_buffer[(layer_id, "qkv_p")] = loaded_weight
                elif "in_proj_qkv.weight_scale" in name:
                    gdn_buffer[(layer_id, "qkv_s")] = loaded_weight
                elif "in_proj_z.weight_packed" in name:
                    gdn_buffer[(layer_id, "z_p")] = loaded_weight
                elif "in_proj_z.weight_scale" in name:
                    gdn_buffer[(layer_id, "z_s")] = loaded_weight
                elif "in_proj_b.weight_packed" in name:
                    gdn_buffer[(layer_id, "b_p")] = loaded_weight
                elif "in_proj_b.weight_scale" in name:
                    gdn_buffer[(layer_id, "b_s")] = loaded_weight
                elif "in_proj_a.weight_packed" in name:
                    gdn_buffer[(layer_id, "a_p")] = loaded_weight
                elif "in_proj_a.weight_scale" in name:
                    gdn_buffer[(layer_id, "a_s")] = loaded_weight
                elif "out_proj.weight_packed" in name:
                    gdn_buffer[(layer_id, "out_p")] = loaded_weight
                elif "out_proj.weight_scale" in name:
                    gdn_buffer[(layer_id, "out_s")] = loaded_weight

                if (layer_id, "qkv_p") in gdn_buffer and (layer_id, "qkv_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "qkv_p"))
                    s = gdn_buffer.pop((layer_id, "qkv_s"))
                    qkv_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_qkvz.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, qkv_fp, (0, 1, 2))
                        loaded_params.add(f"{target_name}.qkv")

                if (layer_id, "z_p") in gdn_buffer and (layer_id, "z_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "z_p"))
                    s = gdn_buffer.pop((layer_id, "z_s"))
                    z_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_qkvz.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, z_fp, 3)
                        loaded_params.add(f"{target_name}.z")

                if (layer_id, "b_p") in gdn_buffer and (layer_id, "b_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "b_p"))
                    s = gdn_buffer.pop((layer_id, "b_s"))
                    b_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_ba.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, b_fp, 0)
                        loaded_params.add(f"{target_name}.b")

                if (layer_id, "a_p") in gdn_buffer and (layer_id, "a_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "a_p"))
                    s = gdn_buffer.pop((layer_id, "a_s"))
                    a_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_ba.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, a_fp, 1)
                        loaded_params.add(f"{target_name}.a")

                if (layer_id, "out_p") in gdn_buffer and (layer_id, "out_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "out_p"))
                    s = gdn_buffer.pop((layer_id, "out_s"))
                    out_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.out_proj.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, out_fp)
                        loaded_params.add(target_name)

                if any(x in name for x in ["in_proj_qkv", "in_proj_z", "in_proj_b", "in_proj_a", "out_proj.weight_packed", "out_proj.weight_scale"]):
                    continue

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if weight_name not in name:
                    continue
                name = name.replace(weight_name, param_name)
                if name in params_dict:
                    param = params_dict[name]
                    weight_loader = getattr(param, "weight_loader", default_weight_loader)
                    weight_loader(param, loaded_weight, shard_id)
                    break
            else:
                if name in params_dict:
                    param = params_dict[name]
                    weight_loader = getattr(param, "weight_loader", default_weight_loader)
                    weight_loader(param, loaded_weight)
                else:
                    logger.warning(f"Parameter {name} not found in params_dict")
            loaded_params.add(name)

        return loaded_params

    @classmethod
    def get_model_config_for_expert_location(cls, config):
        return Qwen3_5Model.get_model_config_for_expert_location(config)

class Qwen3_5ForConditionalGeneration(Qwen3VLForConditionalGeneration):
    packed_modules_mapping = Qwen3_5ForCausalLM.packed_modules_mapping
    hf_to_sglang_mapper = None

    supported_lora_modules = Qwen3_5ForCausalLM.supported_lora_modules

    def __init__(
        self,
        config: Qwen3_5Config,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        language_model_cls=Qwen3_5Model,
    ):
        super().__init__(config, quant_config, prefix, language_model_cls)

        rope_config = getattr(self.config, "rope_parameters", None) or getattr(
            self.config, "rope_scaling", {}
        )
        self.is_mrope_enabled = "mrope_section" in rope_config

        self.deepstack_visual_indexes = self.visual.deepstack_visual_indexes

    def get_hidden_dim(self, module_name: str, layer_idx: int):
        return self.model.get_hidden_dim(module_name, layer_idx)

    def should_apply_lora(self, module_name: str) -> bool:
        return module_name.startswith("model.layers.")

    @property
    def start_layer(self) -> int:
        return getattr(getattr(self, "model", None), "start_layer", 0)

    @property
    def end_layer(self) -> int:
        model = getattr(self, "model", None)
        end_layer = getattr(model, "end_layer", None)
        if end_layer is not None:
            return end_layer
        cfg = getattr(model, "config", None)
        return int(getattr(cfg, "num_hidden_layers", 0))

    def get_embed_and_head(self):
        embed = self.model.embed_tokens.weight if self.pp_group.is_first_rank else None
        head = self.lm_head.weight if self.pp_group.is_last_rank else None
        return embed, head

    def set_embed_and_head(self, embed, head):
        if self.pp_group.is_first_rank and embed is not None:
            del self.model.embed_tokens.weight
            self.model.embed_tokens.weight = embed
        if self.pp_group.is_last_rank and head is not None:
            del self.lm_head.weight
            self.lm_head.weight = head
        if _is_xpu:
            torch.xpu.empty_cache()
            torch.xpu.synchronize()
        else:
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN fused projections
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))
        gdn_buffer = {}
        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")

            if name.endswith(".weight_shape") and ".linear_attn." in name:
                continue

            # GDN compressed-tensors unpacking adapter
            if ".linear_attn." in name:
                layer_id = get_layer_id(name)
                if "in_proj_qkv.weight_packed" in name:
                    gdn_buffer[(layer_id, "qkv_p")] = loaded_weight
                elif "in_proj_qkv.weight_scale" in name:
                    gdn_buffer[(layer_id, "qkv_s")] = loaded_weight
                elif "in_proj_z.weight_packed" in name:
                    gdn_buffer[(layer_id, "z_p")] = loaded_weight
                elif "in_proj_z.weight_scale" in name:
                    gdn_buffer[(layer_id, "z_s")] = loaded_weight
                elif "in_proj_b.weight_packed" in name:
                    gdn_buffer[(layer_id, "b_p")] = loaded_weight
                elif "in_proj_b.weight_scale" in name:
                    gdn_buffer[(layer_id, "b_s")] = loaded_weight
                elif "in_proj_a.weight_packed" in name:
                    gdn_buffer[(layer_id, "a_p")] = loaded_weight
                elif "in_proj_a.weight_scale" in name:
                    gdn_buffer[(layer_id, "a_s")] = loaded_weight
                elif "out_proj.weight_packed" in name:
                    gdn_buffer[(layer_id, "out_p")] = loaded_weight
                elif "out_proj.weight_scale" in name:
                    gdn_buffer[(layer_id, "out_s")] = loaded_weight

                if (layer_id, "qkv_p") in gdn_buffer and (layer_id, "qkv_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "qkv_p"))
                    s = gdn_buffer.pop((layer_id, "qkv_s"))
                    qkv_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_qkvz.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, qkv_fp, (0, 1, 2))
                        loaded_params.add(f"{target_name}.qkv")

                if (layer_id, "z_p") in gdn_buffer and (layer_id, "z_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "z_p"))
                    s = gdn_buffer.pop((layer_id, "z_s"))
                    z_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_qkvz.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, z_fp, 3)
                        loaded_params.add(f"{target_name}.z")

                if (layer_id, "b_p") in gdn_buffer and (layer_id, "b_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "b_p"))
                    s = gdn_buffer.pop((layer_id, "b_s"))
                    b_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_ba.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, b_fp, 0)
                        loaded_params.add(f"{target_name}.b")

                if (layer_id, "a_p") in gdn_buffer and (layer_id, "a_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "a_p"))
                    s = gdn_buffer.pop((layer_id, "a_s"))
                    a_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.in_proj_ba.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, a_fp, 1)
                        loaded_params.add(f"{target_name}.a")

                if (layer_id, "out_p") in gdn_buffer and (layer_id, "out_s") in gdn_buffer:
                    p = gdn_buffer.pop((layer_id, "out_p"))
                    s = gdn_buffer.pop((layer_id, "out_s"))
                    out_fp = unpack_4bit_gdn(p, s)
                    target_name = f"model.layers.{layer_id}.linear_attn.out_proj.weight"
                    if target_name in params_dict:
                        param = params_dict[target_name]
                        weight_loader = getattr(param, "weight_loader", default_weight_loader)
                        weight_loader(param, out_fp)
                        loaded_params.add(target_name)

                if any(x in name for x in ["in_proj_qkv", "in_proj_z", "in_proj_b", "in_proj_a", "out_proj.weight_packed", "out_proj.weight_scale"]):
                    continue
            if (
                self.config.tie_word_embeddings
                and self.pp_group.is_last_rank
                and "model.embed_tokens.weight" in name
            ):
                if "lm_head.weight" in params_dict:
                    lm_head_param = params_dict["lm_head.weight"]
                    weight_loader = getattr(
                        lm_head_param, "weight_loader", default_weight_loader
                    )
                    weight_loader(lm_head_param, loaded_weight)
            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if weight_name not in name:
                    continue

                if "visual" in name or "mlp.experts" in name:
                    continue

                name = name.replace(weight_name, param_name)
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                # Skip layers on other devices.
                # if is_pp_missing_parameter(name, self):
                #     continue
                if name not in params_dict:
                    continue
                param = params_dict[name]
                weight_loader = getattr(param, "weight_loader")
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                if "visual" in name:
                    # adapt to VisionAttention
                    name = name.replace(r"attn.qkv.", r"attn.qkv_proj.")
                    name = name.replace(r"model.visual.", r"visual.")

                # print(name, loaded_weight.shape)
                # Skip loading extra bias for GPTQ models.
                if name.endswith(".bias") and name not in params_dict:
                    continue
                if name not in params_dict:
                    logger.warning(f"Parameter {name} not found in params_dict")
                    continue
                param = params_dict[name]

                weight_loader = getattr(param, "weight_loader", default_weight_loader)
                weight_loader(param, loaded_weight)
                if (
                    self.config.tie_word_embeddings
                    and name == "model.embed_tokens.weight"
                    and (_is_cpu and _is_amx_available)
                ):
                    param_lm_head = params_dict["lm_head.weight"]
                    weight_loader = getattr(
                        param_lm_head, "weight_loader", default_weight_loader
                    )
                    weight_loader(param_lm_head, loaded_weight)
            loaded_params.add(name)
        return loaded_params


class Qwen3_5MoeForConditionalGeneration(Qwen3VLForConditionalGeneration):
    """Qwen3.5 MoE Vision-Language Model."""

    packed_modules_mapping = Qwen3_5ForCausalLM.packed_modules_mapping
    hf_to_sglang_mapper = None

    supported_lora_modules = Qwen3_5ForCausalLM.supported_lora_modules

    def __init__(
        self,
        config: Qwen3_5MoeConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        language_model_cls=Qwen3_5MoeModel,
    ) -> None:
        super().__init__(config, quant_config, prefix, language_model_cls)
        rope_config = getattr(self.config, "rope_parameters", None) or getattr(
            self.config, "rope_scaling", {}
        )
        self.is_mrope_enabled = "mrope_section" in rope_config

        self.deepstack_visual_indexes = self.visual.deepstack_visual_indexes
        self.num_fused_shared_experts = 0
        if _use_aiter and not _disable_shared_experts_fusion():
            self.num_fused_shared_experts = self._get_num_fused_shared_experts()

        self.enable_shared_expert_fusion = self.num_fused_shared_experts > 0

    def get_hidden_dim(self, module_name: str, layer_idx: int):
        return self.model.get_hidden_dim(module_name, layer_idx)

    def should_apply_lora(self, module_name: str) -> bool:
        # Accept all language model layer modules (attention, linear_attn, mlp).
        return module_name.startswith("model.layers.")

    def _get_num_fused_shared_experts(self):
        if not (
            hasattr(self.model, "layers")
            and len(self.model.layers) > 0
            and hasattr(self.model.layers[0].mlp, "num_fused_shared_experts")
        ):
            return 0
        return self.model.layers[0].mlp.num_fused_shared_experts

    def get_embed_and_head(self):
        embed = self.model.embed_tokens.weight if self.pp_group.is_first_rank else None
        head = self.lm_head.weight if self.pp_group.is_last_rank else None
        return embed, head

    def set_embed_and_head(self, embed, head):
        if self.pp_group.is_first_rank and embed is not None:
            del self.model.embed_tokens.weight
            self.model.embed_tokens.weight = embed
        if self.pp_group.is_last_rank and head is not None:
            del self.lm_head.weight
            self.lm_head.weight = head
        if _is_xpu:
            torch.xpu.empty_cache()
            torch.xpu.synchronize()
        else:
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        stacked_params_mapping = [
            # (param_name, shard_name, shard_id)
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
            # GDN fused projections
            ("in_proj_qkvz.", "in_proj_qkv.", (0, 1, 2)),
            ("in_proj_qkvz.", "in_proj_z.", 3),
            ("in_proj_ba.", "in_proj_b.", 0),
            ("in_proj_ba.", "in_proj_a.", 1),
        ]

        num_experts = self.config.num_experts

        # Params for weights, fp8 weight scales, fp8 activation scales
        # (param_name, weight_name, expert_id, shard_id)
        expert_params_mapping = FusedMoE.make_expert_params_mapping(
            ckpt_gate_proj_name="gate_proj",
            ckpt_down_proj_name="down_proj",
            ckpt_up_proj_name="up_proj",
            num_experts=(
                num_experts
                if not self.enable_shared_expert_fusion
                else num_experts + self.num_fused_shared_experts
            ),
        )

        # Skip loading extra parameters for GPTQ/modelopt models.
        ignore_suffixes = (
            ".bias",
            "_bias",
            ".k_scale",
            "_k_scale",
            ".v_scale",
            "_v_scale",
            "_weight_scale",
            "_input_scale",
        )

        is_fused_expert = False
        fused_expert_params_mapping = [
            ("experts.w13_weight", "experts.gate_up_proj", 0, "w1"),
            ("experts.w2_weight", "experts.down_proj", 0, "w2"),
        ]

        if self.enable_shared_expert_fusion:
            """
            When shared experts are fused, we need to map the shared experts to routed experts.

            mlp.share_expert.gate_up_proj.weight  --> experts.512.gate_up_proj.weight -> experts.w13_weight, expert_id = 512
            mlp.share_expert.down_proj.weight  --> experts.512.down_proj.weight -> experts.w2_weight, expert_id = 512
            """
            fused_expert_params_mapping += [
                (
                    "experts.w13_",
                    f"experts.{num_experts}.gate_up_proj.",
                    num_experts,
                    "w1",
                ),
                (
                    "experts.w2_",
                    f"experts.{num_experts}.down_proj.",
                    num_experts,
                    "w2",
                ),
                ## shared experts may contain gate_proj and up_proj instead of gate_up_proj
                (
                    "experts.w13_",
                    f"experts.{num_experts}.gate_proj.",
                    num_experts,
                    "w1",
                ),
                (
                    "experts.w13_",
                    f"experts.{num_experts}.up_proj.",
                    num_experts,
                    "w3",
                ),
            ]

        def load_fused_expert_weights(
            name: str,
            params_dict: dict,
            loaded_weight: torch.Tensor,
            shard_id: str,
            num_experts: int,
        ):
            if name not in params_dict:
                return False
            param = params_dict[name]
            weight_loader = param.weight_loader
            # let ep moe layer to gracefully handle expert_ids that do not belong to local moe rank
            for expert_id in range(num_experts):
                curr_expert_weight = loaded_weight[expert_id]
                weight_loader(
                    param,
                    curr_expert_weight,
                    name,
                    shard_id,
                    expert_id,
                )
            return True

        loaded_params: Set[str] = set()
        params_dict = dict(self.named_parameters(remove_duplicate=False))

        for name, loaded_weight in weights:
            if "rotary_emb.inv_freq" in name:
                continue
            if "mtp" in name:
                continue
            if "language_model" in name:
                name = name.replace(r"model.language_model.", r"model.")
            if ".self_attn." in name:
                name = name.replace(".self_attn", "")
            if (
                self.config.tie_word_embeddings
                and self.pp_group.is_last_rank
                and "model.embed_tokens.weight" in name
            ):
                if "lm_head.weight" in params_dict:
                    lm_head_param = params_dict["lm_head.weight"]
                    weight_loader = getattr(
                        lm_head_param, "weight_loader", default_weight_loader
                    )
                    weight_loader(lm_head_param, loaded_weight)

            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self, "start_layer")
                and (layer_id < self.start_layer or layer_id >= self.end_layer)
            ):
                continue

            if self.enable_shared_expert_fusion:
                if "mlp.shared_expert." in name:
                    # Firstly map mlp.shared_expert.xx_proj to mlp.experts.512.xx_proj
                    name = name.replace(
                        "mlp.shared_expert.",
                        f"mlp.experts.{num_experts}.",
                    )

            for param_name, weight_name, shard_id in stacked_params_mapping:
                if name.endswith("experts.gate_up_proj") or name.endswith(
                    "experts.down_proj"
                ):
                    is_fused_expert = True
                    expert_params_mapping = fused_expert_params_mapping

                # Skip non-stacked layers and experts (experts handled below).
                if weight_name not in name:
                    continue
                if "visual" in name:
                    continue

                # We have mlp.experts[0].gate_proj in the checkpoint.
                # Since we handle the experts below in expert_params_mapping,
                # we need to skip here BEFORE we update the name, otherwise
                # name will be updated to mlp.experts[0].gate_up_proj, which
                # will then be updated below in expert_params_mapping
                # for mlp.experts[0].gate_gate_up_proj, which breaks load.
                if "mlp.experts" in name:
                    continue
                name = name.replace(weight_name, param_name)
                # Skip loading extra parameters for GPTQ/modelopt models.
                if name.endswith(ignore_suffixes) and name not in params_dict:
                    continue

                if name not in params_dict:
                    continue

                param = params_dict[name]
                weight_loader = param.weight_loader
                weight_loader(param, loaded_weight, shard_id)
                break
            else:
                # Track if this is an expert weight to enable early skipping
                is_expert_weight = False

                for mapping in expert_params_mapping:
                    param_name, weight_name, expert_id, shard_id = mapping
                    if weight_name not in name:
                        continue
                    if "visual" in name or self.config.encoder_only:
                        continue
                    # Anyway, this is an expert weight and should not be
                    # attempted to load as other weights later
                    is_expert_weight = True
                    name_mapped = name.replace(weight_name, param_name)
                    if is_fused_expert:
                        # is_fused_expert is True, the checkpoint contains gate_up_proj and down_proj for each expert
                        if "experts.gate_up_proj" in name:
                            # experts.gate_up_proj contains all 512 routed experts, excluding shared experts
                            # split into w1 and w3
                            loaded_weight = loaded_weight.chunk(2, dim=-2)
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[0],
                                "w1",
                                num_experts,
                            )
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight[1],
                                "w3",
                                num_experts,
                            )
                        elif "experts.down_proj" in name:
                            # experts.down_proj contains all 512 routed experts, excluding shared experts
                            load_fused_expert_weights(
                                name_mapped,
                                params_dict,
                                loaded_weight,
                                shard_id,
                                num_experts,
                            )
                        elif self.enable_shared_expert_fusion:
                            # shared experts should be loaded to experts.w13_weight and experts.w2_weight
                            param = params_dict[name_mapped]
                            weight_loader = getattr(
                                param, "weight_loader", default_weight_loader
                            )
                            param = params_dict[name_mapped]
                            if f"{num_experts}.gate_up_proj" in name:
                                # split into w1 and w3
                                loaded_weight = loaded_weight.chunk(2, dim=-2)
                                # load to experts.w13_weight, shard_id = w1, expert_id = 512
                                weight_loader(
                                    param,
                                    loaded_weight[0],
                                    name_mapped,
                                    "w1",
                                    expert_id,
                                )
                                # load to experts.w13_weight, shard_id = w3, expert_id = 512
                                weight_loader(
                                    param,
                                    loaded_weight[1],
                                    name_mapped,
                                    "w3",
                                    expert_id,
                                )
                            else:
                                # load down_proj to experts.w2_weight, shard_id = w2, expert_id = 512
                                # Or load gate_proj and up_proj to experts.w13_weight, shard_id = w1/w3, expert_id = 512
                                weight_loader(
                                    param,
                                    loaded_weight,
                                    name_mapped,
                                    shard_id,
                                    expert_id,
                                )
                    else:
                        # Skip loading extra parameters for GPTQ models.
                        if (
                            name_mapped.endswith(ignore_suffixes)
                            and name_mapped not in params_dict
                        ):
                            continue
                        param = params_dict[name_mapped]
                        # We should ask the weight loader to return success or
                        # not here since otherwise we may skip experts with
                        # # other available replicas.
                        weight_loader = param.weight_loader
                        weight_loader(
                            param,
                            loaded_weight,
                            name_mapped,
                            shard_id=shard_id,
                            expert_id=expert_id,
                        )
                    name = name_mapped
                    break
                else:
                    if is_expert_weight:
                        # This is an expert weight but not mapped to this rank, skip all remaining processing
                        continue

                    if "visual" in name:
                        # adapt to VisionAttention
                        name = name.replace(r"attn.qkv.", r"attn.qkv_proj.")
                        name = name.replace(r"model.visual.", r"visual.")

                    # Skip loading extra parameters for GPTQ/modelopt models.
                    if name.endswith(ignore_suffixes) and name not in params_dict:
                        continue

                    if name in params_dict.keys():
                        param = params_dict[name]
                        weight_loader = getattr(
                            param, "weight_loader", default_weight_loader
                        )
                        weight_loader(param, loaded_weight)
                    else:
                        logger.warning(f"Parameter {name} not found in params_dict")
            loaded_params.add(name)

        self._routed_experts_weights_of_layer = LazyValue(
            lambda: {
                layer_id: layer.mlp.get_moe_weights()
                for layer_id, layer in enumerate(self.model.layers)
                if isinstance(layer.mlp, Qwen2MoeSparseMoeBlock)
            }
        )

        return loaded_params

    @property
    def routed_experts_weights_of_layer(self):
        return self._routed_experts_weights_of_layer.value

    @classmethod
    def get_model_config_for_expert_location(cls, config):
        text_config = getattr(config, "text_config", config)
        return ModelConfigForExpertLocation(
            num_layers=getattr(text_config, "num_hidden_layers", 0),
            num_logical_experts=getattr(text_config, "num_experts", 0),
            num_groups=None,
        )


EntryClass = [Qwen3_5ForCausalLM, Qwen3_5ForConditionalGeneration, Qwen3_5MoeForConditionalGeneration]
